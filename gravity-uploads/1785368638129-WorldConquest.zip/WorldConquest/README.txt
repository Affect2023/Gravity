World Conquest Sandbox 1.1.12 for Hearts of Iron IV 1.17.x

What this mod does:
- Lets every ideology justify wars.
- Uses a valid HOI4 1.17.x compatibility descriptor so the game loads the mod and its custom rules.
- Adds an "Instant Declare War" setup rule with Disabled, Player Only, and Everyone options.
- When Instant Declare War is enabled, selected countries receive conquest war goals against other countries so the normal Declare War button has a valid war goal.
- Adds a "Refresh Conquest War Goals" decision for already-started saves or cases where the diplomacy button still says no war goal.
- Adds a "Capital Sniping" setup rule with Disabled, Player Only, and Everyone options.
- Adds a "Construction Speed" setup rule with Normal x1, Fast x2, Very Fast x4, and Extreme x8 options.
- Adds a "Training Speed" setup rule with Normal x1, Fast x2, Very Fast x4, and Extreme x8 options.
- Adds a "Research Speed" setup rule with Normal x1, Fast x2, Very Fast x4, and Extreme x8 options.
- Adds a "Political Power Speed" setup rule with Normal x1, Fast x2, Very Fast x4, and Extreme x8 options.
- Adds a "Military XP Speed" setup rule with Normal x1, Fast x2, Very Fast x4, and Extreme x8 options.
- Custom World Conquest setup rules appear under their own "World Conquest Sandbox" rule group.
- When Capital Sniping is enabled, capturing an enemy-owned capital state pushes that country into normal capitulation instead of direct annexation, so peace conferences can still divide land.
- Peace conferences give more usable score so multiplayer winners can afford states after small-country wars.
- When enabled, manual war justification is as fast as the game normally allows through defines and modifiers.
- When enabled, world tension requirements for justifying wars are removed where HOI4 exposes that behavior to mods.
- Lets the human player create and join factions regardless of ideology.
- Allows mixed-ideology factions, such as fascist and communist countries in the same faction.
- Blocks AI countries from creating factions, but allows them to join factions so player alliances can work at 0% world tension.
- Strongly discourages AI countries from calling allies or joining allied wars.
- Blocks new guarantees by default.
- Removes active guarantees at game start.
- Removes several ideology restrictions around aggressive diplomacy.
- Construction speed can be changed in the game setup menu. The default is x4 for factories, infrastructure, railways, supply hubs, forts, and other buildings.
- Division training speed, research speed, political power gain, and military XP gain can be changed in the game setup menu.
- Greatly reduces internal overthrow risk with high stability, war stability, ideology drift defense, and lower resistance growth.

Installed files:
- The mod itself is in D:/HOI mods/WorldConquest.
- The launcher pointer is C:/Users/lukeg/Documents/Paradox Interactive/Hearts of Iron IV/mod/WorldConquest.mod.

Notes:
- Capital Sniping now uses normal HOI4 capitulation pressure rather than direct annexation. The country may capitulate on the next game check instead of the exact frame the capital falls.
- HOI4's full console-style no_wargoal toggle appears to be console-only. The setup rule now uses real conquest war goals so the normal diplomacy Declare War button can work without waiting for manual justification.
- Enable "World Conquest Sandbox" in the Paradox launcher before starting a game.
