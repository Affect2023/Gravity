-- World Conquest defines.
-- These values reduce the remaining hard-coded cost and delay around manually
-- justifying war goals. The national spirit handles the ideology and tension
-- restrictions that are exposed as country rules and modifiers.
NDefines.NDiplomacy.MIN_WARGOAL_JUSTIFY_COST = 1.0
NDefines.NDiplomacy.WARGOAL_WORLD_TENSION_REDUCTION = -1.0
NDefines.NDiplomacy.WARGOAL_JUSTIFY_TENSION_FROM_PRODUCTION = 0.0
NDefines.NDiplomacy.IDEOLOGY_JOIN_FACTION_MIN_LEVEL = 0.0
NDefines.NDiplomacy.JOIN_FACTION_LIMIT_CHANGE_AT_WAR = 0.0
NDefines.NDiplomacy.TENSION_FACTION_JOIN = 0

-- Peace conferences in fast conquest games can underpay winners, especially
-- in multiplayer where two players split score after a small country falls.
-- These values raise the available score and give it up front so states that
-- cost 100+ points can actually be taken.
NDefines.NDiplomacy.PEACE_SCORE_SCALE_FACTOR = 8.0
NDefines.NDiplomacy.PEACE_SCORE_MINOR_BOOST_FRACTION = 0.25
NDefines.NDiplomacy.PEACE_SCORE_DISTRIBUTION = { 1.0 }
NDefines.NDiplomacy.BASE_PEACE_TAKE_UNCONTROLLED_STATE_FACTOR = 2.0
NDefines.NDiplomacy.BASE_PEACE_TAKE_FACTION_CONTROLLED_STATE_FACTOR = 0.25
NDefines.NDiplomacy.PEACE_COST_FACTOR_UNCONTESTED_BID_MIN = 1.0
NDefines.NDiplomacy.PEACE_COST_FACTOR_UNCONTESTED_BID_MAX = 1.0
NDefines.NDiplomacy.PEACE_COST_FACTOR_UNCONTESTED_BID_STEP = 0.0

-- Discourage AI faction behavior globally. Country rules below are the main
-- lock, while these defines reduce AI desire if another script enables rules.
NDefines.NAI.DIPLOMACY_CREATE_FACTION_FACTOR = 0.0
NDefines.NAI.DIPLOMACY_FACTION_WRONG_IDEOLOGY_PENALTY = 0
NDefines.NAI.DIPLOMACY_FACTION_NEUTRALITY_PENALTY = 0
NDefines.NAI.DIPLOMACY_FACTION_SAME_IDEOLOGY_MAJOR = 0
NDefines.NAI.DIPLOMACY_FACTION_GLOBAL_TENSION_FACTOR = 0.0
NDefines.NAI.DIPLOMACY_FACTION_WAR_RELUCTANCE = 0
NDefines.NAI.DIPLOMACY_FACTION_WAR_WANTS_HELP = -1000
NDefines.NAI.DIPLOMACY_FACTION_CIVILWAR_WANTS_HELP = -1000
NDefines.NAI.DIPLOMACY_FACTION_MAJOR_AT_WAR = 0.0
NDefines.NAI.DIPLOMACY_FACTION_PLAYER_JOIN = 1000
NDefines.NAI.FACTION_UNSTABLE_ACCEPTANCE = -1000

-- Stop war dogpiles. These make AI countries avoid calling allies or joining
-- allied wars, so your invasions stay mostly one-on-one instead of turning into
-- surprise world wars.
NDefines.NAI.AI_CHAIN_CALLS_ALLIES = false
NDefines.NAI.CALL_ALLY_BASE_DESIRE = -1000
NDefines.NAI.CALL_ALLY_DEMOCRATIC_DESIRE = -1000
NDefines.NAI.CALL_ALLY_NEUTRAL_DESIRE = -1000
NDefines.NAI.CALL_ALLY_FASCIST_DESIRE = -1000
NDefines.NAI.CALL_ALLY_COMMUNIST_DESIRE = -1000
NDefines.NAI.CALL_ALLY_PUPPET_INVITE_OVERLORD = -1000
NDefines.NAI.CALL_ALLY_OVERLORD_INVITE_PUPPET = -1000
NDefines.NAI.CALL_ALLY_RELATIVE_INDUSTRY_STRENGTH_MAX = 0.0
NDefines.NAI.CALL_ALLY_RELATIVE_ARMY_STRENGTH_MAX = 0.0
NDefines.NAI.CALL_ALLY_LOSING_WAR_MAX = 0.0
NDefines.NAI.CALL_ALLY_WAR_LENGTH_NR_MONTHS = 0
NDefines.NAI.CALL_ALLY_JOINER_HAS_ENEMY_NEIGHBOR = -1000
NDefines.NAI.JOIN_ALLY_BASE_DESIRE = -1000
NDefines.NAI.JOIN_ALLY_DEMOCRATIC_DESIRE = -1000
NDefines.NAI.JOIN_ALLY_NEUTRAL_DESIRE = -1000
NDefines.NAI.JOIN_ALLY_FASCIST_DESIRE = -1000
NDefines.NAI.JOIN_ALLY_COMMUNIST_DESIRE = -1000
NDefines.NAI.POTENTIAL_ALLY_JOIN_WAR_FACTOR = 0
