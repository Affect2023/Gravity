version="1.1.12"
tags={
	"Gameplay"
	"Alternative History"
}
name="World Conquest Sandbox"
picture="thumbnail.png"
supported_version="1.17.*"
remote_file_id="3766795564"