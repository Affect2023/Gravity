@echo off
set STEAMCMD=C:\steamcmd\steamcmd.exe
if not exist "%STEAMCMD%" (
  echo SteamCMD was not found at C:\steamcmd\steamcmd.exe
  echo Download SteamCMD from Valve and extract it to C:\steamcmd\ first.
  pause
  exit /b 1
)
"%STEAMCMD%" +login %1 +workshop_build_item "D:\HOI mods\WorldConquest\workshop_preview_update.vdf" +quit
pause
